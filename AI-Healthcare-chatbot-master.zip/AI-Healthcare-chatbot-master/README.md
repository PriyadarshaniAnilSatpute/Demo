# AI-Healthcare-chatbot
Through a series of questions about symptoms it diagnosis the health condition of patient. <br />
Language     : python. <br />
modules used : scikit-learn,pandas,numpy <br />
Model        : Decision Tree

